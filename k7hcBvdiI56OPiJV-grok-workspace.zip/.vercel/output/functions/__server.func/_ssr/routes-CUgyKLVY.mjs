import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Sun, r as Moon } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CUgyKLVY.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SUPPLY = 1e9;
function parseAmount(raw) {
	const trimmed = raw.trim().toLowerCase().replace(/\s/g, "").replace(",", ".");
	if (!trimmed) return NaN;
	let mult = 1;
	let body = trimmed;
	const suffix = body.at(-1);
	if (suffix === "b") {
		mult = 1e9;
		body = body.slice(0, -1);
	} else if (suffix === "m") {
		mult = 1e6;
		body = body.slice(0, -1);
	} else if (suffix === "k") {
		mult = 1e3;
		body = body.slice(0, -1);
	}
	const n = Number(body);
	return Number.isFinite(n) ? n * mult : NaN;
}
function compute(fdv, pct, total, user) {
	if (![
		fdv,
		pct,
		total,
		user
	].every(Number.isFinite)) return null;
	if (fdv < 0 || pct < 0 || pct > 100 || total <= 0 || user < 0) return null;
	const pool = fdv * (pct / 100);
	const dropTokens = SUPPLY * (pct / 100);
	const share = user / total;
	return {
		pool,
		dropTokens,
		tokenPrice: fdv / SUPPLY,
		pointPrice: pool / total,
		share,
		userUsd: user * (pool / total),
		userTokens: dropTokens * share
	};
}
function parts(abs, maxDigits, minDigits) {
	const [whole, frac = ""] = abs.toFixed(maxDigits).split(".");
	let tail = frac;
	if (tail.length > minDigits) {
		tail = tail.replace(/0+$/, "");
		if (tail.length < minDigits) tail = tail.padEnd(minDigits, "0");
	}
	return {
		whole,
		tail
	};
}
function group(whole, sep) {
	return whole.replace(/\B(?=(\d{3})+(?!\d))/g, sep);
}
function number(n, lang, maxDigits, minDigits) {
	const sep = lang === "ru" ? "\xA0" : ",";
	const dec = lang === "ru" ? "," : ".";
	const { whole, tail } = parts(Math.abs(n), maxDigits, minDigits);
	const body = tail ? `${group(whole, sep)}${dec}${tail}` : group(whole, sep);
	return n < 0 ? `-${body}` : body;
}
function moneyDigits(abs) {
	if (abs > 0 && abs < 1e-4) return {
		max: 8,
		min: 0
	};
	if (abs > 0 && abs < .01) return {
		max: 6,
		min: 0
	};
	if (abs > 0 && abs < 1) return {
		max: 4,
		min: 0
	};
	return {
		max: 2,
		min: 2
	};
}
function money(n, lang) {
	const { max, min } = moneyDigits(Math.abs(n));
	const body = number(n, lang, max, min);
	return lang === "ru" ? `${body}\u00a0$` : `$${body}`;
}
function compactUsd(n, lang) {
	const abs = Math.abs(n);
	for (const [div, suffix] of [
		[0xe8d4a51000, "T"],
		[1e9, "B"],
		[1e6, "M"],
		[1e3, "K"]
	]) if (abs >= div) {
		const scaled = n / div;
		const body = number(scaled, lang, Number.isInteger(scaled) || Math.abs(scaled) >= 100 ? 0 : 2, 0);
		return lang === "ru" ? `${body}\u00a0${suffix}\u00a0$` : `$${body}${suffix}`;
	}
	return money(n, lang);
}
function compactNum(n, lang) {
	const abs = Math.abs(n);
	for (const [div, suffix] of [
		[0xe8d4a51000, "T"],
		[1e9, "B"],
		[1e6, "M"],
		[1e3, "K"]
	]) if (abs >= div) {
		const scaled = n / div;
		return `${number(scaled, lang, Number.isInteger(scaled) || Math.abs(scaled) >= 100 ? 0 : 2, 0)}\u00a0${suffix}`;
	}
	return number(n, lang, 0, 0);
}
function tokens(n, lang) {
	return number(n, lang, Math.abs(n) >= 100 ? 0 : 2, 0);
}
function percent(share, lang) {
	const pct = share * 100;
	const abs = Math.abs(pct);
	return `${number(pct, lang, abs > 0 && abs < .01 ? 6 : abs < 1 ? 4 : 2, 0)}%`;
}
var LANGS = [
	"en",
	"ru",
	"zh"
];
var LANG_LABEL = {
	en: "EN",
	ru: "RU",
	zh: "中文"
};
var copy = {
	ru: {
		kicker: "Predict.fun",
		title: "Калькулятор аирдропа",
		sub: "Цена одного поинта и размер дропа в долларах. Саплай зафиксирован: 1 млрд токенов.",
		lang: "Язык",
		themeToLight: "Светлая тема",
		themeToDark: "Тёмная тема",
		inputs: "Входные данные",
		results: "Результат",
		fdv: "FDV, $",
		pct: "Доля на дроп, %",
		total: "Всего поинтов",
		yours: "Ваши поинты",
		hint: "Можно писать 150m, 1.5b, 25k",
		point: "Цена 1 поинта",
		drop: "Ваш аирдроп",
		tokens: "Ваши токены",
		tokenPrice: "Цена токена",
		pool: "Пул дропа",
		share: "Ваша доля",
		pointOf: (pool, points) => `${pool} / ${points} поинтов`,
		dropOf: (points, price) => `${points} × ${price}`,
		how: "Как считается",
		lead: "Долларовая ценность дропа — это FDV, умноженный на долю аллокации. Цена токена уже сидит внутри FDV.",
		rows: [
			["Пул, $", "FDV × (% / 100)"],
			["Токенов в дропе", "1 000 000 000 × (% / 100)"],
			["Цена токена", "FDV / 1 000 000 000"],
			["Цена 1 поинта", "пул $ / все поинты"],
			["Аирдроп, $", "ваши поинты × цена поинта"],
			["Ваши токены", "токены в дропе × (ваши / все)"]
		],
		assume: "Допущение: весь процент делится пропорционально поинтам, без капов, мультипликаторов и отдельных бакетов.",
		disclaimer: "Predict.fun не публиковал токеномику и дату TGE. FDV, процент и итоговое число поинтов — сценарии, не факт. Не финансовый совет.",
		warnOver: "Ваши поинты больше общего числа — доля выше 100%.",
		warnRange: "FDV и поинты должны быть ≥ 0, доля от 0 до 100, всего поинтов больше 0.",
		warnBad: "Введите числа. Можно писать 150m, 1.5b или 25k."
	},
	en: {
		kicker: "Predict.fun",
		title: "Airdrop calculator",
		sub: "Price of one point and your drop in dollars. Supply is fixed at 1 billion tokens.",
		lang: "Language",
		themeToLight: "Light theme",
		themeToDark: "Dark theme",
		inputs: "Inputs",
		results: "Result",
		fdv: "FDV, $",
		pct: "Airdrop allocation, %",
		total: "Total points",
		yours: "Your points",
		hint: "You can type 150m, 1.5b, 25k",
		point: "Price of 1 point",
		drop: "Your airdrop",
		tokens: "Your tokens",
		tokenPrice: "Token price",
		pool: "Airdrop pool",
		share: "Your share",
		pointOf: (pool, points) => `${pool} / ${points} points`,
		dropOf: (points, price) => `${points} × ${price}`,
		how: "How it’s calculated",
		lead: "The dollar value of the drop is FDV times the allocation. Token price is already inside the FDV.",
		rows: [
			["Pool, $", "FDV × (% / 100)"],
			["Drop tokens", "1,000,000,000 × (% / 100)"],
			["Token price", "FDV / 1,000,000,000"],
			["Price of 1 point", "pool $ / total points"],
			["Airdrop, $", "your points × point price"],
			["Your tokens", "drop tokens × (yours / total)"]
		],
		assume: "Assumption: the whole allocation is split pro-rata by points, with no caps, multipliers, or separate buckets.",
		disclaimer: "Predict.fun has not published tokenomics or a TGE date. FDV, allocation, and the final point total are scenarios, not facts. Not financial advice.",
		warnOver: "Your points exceed the total — share is above 100%.",
		warnRange: "FDV and points must be ≥ 0, allocation 0–100, and total points greater than 0.",
		warnBad: "Enter numbers. You can type 150m, 1.5b, or 25k."
	},
	zh: {
		kicker: "Predict.fun",
		title: "空投计算器",
		sub: "单个积分的价格，以及你的空投美元价值。总供应固定为 10 亿枚代币。",
		lang: "语言",
		themeToLight: "浅色主题",
		themeToDark: "深色主题",
		inputs: "输入",
		results: "结果",
		fdv: "FDV, $",
		pct: "空投比例, %",
		total: "总积分",
		yours: "你的积分",
		hint: "可以输入 150m、1.5b、25k",
		point: "1 积分价格",
		drop: "你的空投",
		tokens: "你的代币",
		tokenPrice: "代币价格",
		pool: "空投池",
		share: "你的份额",
		pointOf: (pool, points) => `${pool} / ${points} 积分`,
		dropOf: (points, price) => `${points} × ${price}`,
		how: "计算方式",
		lead: "空投的美元价值等于 FDV 乘以分配比例。代币价格已经包含在 FDV 里。",
		rows: [
			["空投池, $", "FDV × (% / 100)"],
			["空投代币数", "1,000,000,000 × (% / 100)"],
			["代币价格", "FDV / 1,000,000,000"],
			["1 积分价格", "空投池 $ / 总积分"],
			["空投, $", "你的积分 × 积分价格"],
			["你的代币", "空投代币数 × (你的 / 总积分)"]
		],
		assume: "假设：全部比例按积分比例分配，没有上限、倍数或单独的份额。",
		disclaimer: "Predict.fun 尚未公布代币经济模型和 TGE 日期。FDV、分配比例和最终积分总量都是情景假设，不是事实。不构成财务建议。",
		warnOver: "你的积分超过总量，份额会高于 100%。",
		warnRange: "FDV 和积分必须 ≥ 0，分配比例在 0 到 100 之间，总积分必须大于 0。",
		warnBad: "请输入数字。可以写 150m、1.5b 或 25k。"
	}
};
var FDV_PRESETS = [
	{
		label: "$50M",
		value: "50000000"
	},
	{
		label: "$100M",
		value: "100000000"
	},
	{
		label: "$150M",
		value: "150000000"
	},
	{
		label: "$300M",
		value: "300000000"
	},
	{
		label: "$500M",
		value: "500000000"
	},
	{
		label: "$1B",
		value: "1000000000"
	}
];
var PCT_PRESETS = [
	"5",
	"8",
	"10",
	"15",
	"20"
];
var TOTAL_PRESETS = [
	{
		label: "100M",
		value: "100000000"
	},
	{
		label: "200M",
		value: "200000000"
	},
	{
		label: "500M",
		value: "500000000"
	},
	{
		label: "1B",
		value: "1000000000"
	}
];
var USER_PRESETS = [
	{
		label: "1K",
		value: "1000"
	},
	{
		label: "5K",
		value: "5000"
	},
	{
		label: "25K",
		value: "25000"
	},
	{
		label: "100K",
		value: "100000"
	},
	{
		label: "500K",
		value: "500000"
	}
];
var DEFAULTS = {
	fdv: "150000000",
	pct: "10",
	total: "200000000",
	user: "25000"
};
function sameAmount(raw, preset) {
	const a = parseAmount(raw);
	const b = parseAmount(preset);
	return Number.isFinite(a) && a === b;
}
function Calculator() {
	const [lang, setLang] = (0, import_react.useState)("en");
	const [theme, setTheme] = (0, import_react.useState)("dark");
	const [inputs, setInputs] = (0, import_react.useState)(DEFAULTS);
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	const t = copy[lang];
	(0, import_react.useEffect)(() => {
		try {
			if (localStorage.getItem("pf-lang-pin") === "1") {
				const savedLang = localStorage.getItem("pf-lang");
				if (savedLang === "en" || savedLang === "ru" || savedLang === "zh") setLang(savedLang);
			}
			const savedTheme = localStorage.getItem("pf-theme");
			if (savedTheme === "light" || savedTheme === "dark") setTheme(savedTheme);
			const raw = localStorage.getItem("pf-inputs");
			if (raw) {
				const parsed = JSON.parse(raw);
				setInputs((prev) => ({
					fdv: typeof parsed.fdv === "string" ? parsed.fdv : prev.fdv,
					pct: typeof parsed.pct === "string" ? parsed.pct : prev.pct,
					total: typeof parsed.total === "string" ? parsed.total : prev.total,
					user: typeof parsed.user === "string" ? parsed.user : prev.user
				}));
			}
		} catch {}
		setHydrated(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		localStorage.setItem("pf-lang", lang);
		document.documentElement.lang = lang === "zh" ? "zh-CN" : lang;
	}, [hydrated, lang]);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		localStorage.setItem("pf-theme", theme);
		document.documentElement.dataset.theme = theme;
	}, [hydrated, theme]);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		localStorage.setItem("pf-inputs", JSON.stringify(inputs));
	}, [hydrated, inputs]);
	const fdv = parseAmount(inputs.fdv);
	const pct = parseAmount(inputs.pct);
	const total = parseAmount(inputs.total);
	const user = parseAmount(inputs.user);
	const result = (0, import_react.useMemo)(() => compute(fdv, pct, total, user), [
		fdv,
		pct,
		total,
		user
	]);
	let warning = "";
	if (!result) warning = [
		fdv,
		pct,
		total,
		user
	].some(Number.isFinite) && (Number.isFinite(fdv) && fdv < 0 || Number.isFinite(pct) && (pct < 0 || pct > 100) || Number.isFinite(total) && total <= 0 || Number.isFinite(user) && user < 0) ? t.warnRange : t.warnBad;
	else if (user > total) warning = t.warnOver;
	function setField(key, value) {
		setInputs((prev) => ({
			...prev,
			[key]: value
		}));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto min-h-screen max-w-5xl px-4 py-8 sm:px-6 sm:py-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-8 flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						"aria-hidden": "true",
						className: "grid size-11 shrink-0 place-items-center rounded-xl bg-lime font-mono text-xl font-semibold text-lime-ink",
						children: "P"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium tracking-wide text-accent",
							children: t.kicker
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-3xl font-semibold leading-tight tracking-tight sm:text-4xl",
							children: t.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 max-w-xl text-sm text-muted sm:text-base",
							children: t.sub
						})
					] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-pressed": theme === "light",
						"aria-label": theme === "light" ? t.themeToDark : t.themeToLight,
						onClick: () => setTheme((current) => current === "light" ? "dark" : "light"),
						className: "grid size-11 place-items-center rounded-full border border-line text-fg",
						children: theme === "light" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						role: "group",
						"aria-label": t.lang,
						className: "inline-flex rounded-full border border-line p-1",
						children: LANGS.map((code) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-pressed": lang === code,
							onClick: () => {
								localStorage.setItem("pf-lang-pin", "1");
								setLang(code);
							},
							className: "min-h-11 rounded-full px-3 text-sm font-semibold transition-colors " + (lang === code ? "bg-lime text-lime-ink" : "text-muted"),
							children: LANG_LABEL[code]
						}, code))
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl border border-line bg-surface p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-medium text-muted",
							children: t.inputs
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							id: "fdv",
							label: t.fdv,
							value: inputs.fdv,
							onChange: (v) => setField("fdv", v),
							presets: FDV_PRESETS
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs text-muted",
							children: t.hint
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							id: "pct",
							label: t.pct,
							value: inputs.pct,
							onChange: (v) => setField("pct", v),
							presets: PCT_PRESETS.map((value) => ({
								label: `${value}%`,
								value
							}))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							id: "total",
							label: t.total,
							value: inputs.total,
							onChange: (v) => setField("total", v),
							presets: TOTAL_PRESETS
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							id: "user",
							label: t.yours,
							value: inputs.user,
							onChange: (v) => setField("user", v),
							presets: USER_PRESETS
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 min-h-5 text-sm text-warn",
							role: "status",
							children: warning
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl border border-line bg-surface p-5",
					"aria-live": "polite",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium text-muted",
						children: t.results
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {
								label: t.point,
								value: result ? money(result.pointPrice, lang) : "—",
								hint: result ? t.pointOf(compactUsd(result.pool, lang), compactNum(total, lang)) : t.pointOf("—", "—")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {
								label: t.drop,
								value: result ? money(result.userUsd, lang) : "—",
								hint: result ? t.dropOf(compactNum(user, lang), money(result.pointPrice, lang)) : t.dropOf("—", "—")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										label: t.tokens,
										value: result ? tokens(result.userTokens, lang) : "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										label: t.tokenPrice,
										value: result ? money(result.tokenPrice, lang) : "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										label: t.pool,
										value: result ? compactUsd(result.pool, lang) : "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										label: t.share,
										value: result ? percent(result.share, lang) : "—"
									})
								]
							})
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-4 rounded-2xl border border-line bg-surface p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold tracking-tight",
						children: t.how
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-3xl text-sm text-muted",
						children: t.lead
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 space-y-2",
						children: t.rows.map(([label, expr]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex flex-col gap-0.5 text-sm sm:flex-row sm:items-baseline sm:gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted sm:w-44 sm:shrink-0",
								children: label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
								className: "font-mono text-fg",
								children: expr
							})]
						}, label))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm text-muted",
						children: t.assume
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-3xl text-xs leading-relaxed text-muted",
				children: t.disclaimer
			})
		]
	});
}
function Field({ id, label, value, onChange, presets }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				htmlFor: id,
				className: "mb-2 block text-sm text-muted",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				id,
				value,
				inputMode: "decimal",
				autoComplete: "off",
				onChange: (e) => onChange(e.target.value),
				className: "min-h-11 w-full rounded-xl border border-line bg-surface-2 px-4 font-mono text-base text-fg"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 flex flex-wrap gap-2",
				children: presets.map((preset) => {
					const active = sameAmount(value, preset.value);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-pressed": active,
						onClick: () => onChange(preset.value),
						className: "min-h-11 rounded-full border px-3 text-sm font-medium transition-colors " + (active ? "border-lime bg-lime text-lime-ink" : "border-line text-muted"),
						children: preset.label
					}, preset.value);
				})
			})
		]
	});
}
function Hero({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-line bg-surface-2 px-4 py-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-mono text-3xl font-semibold tracking-tight text-accent sm:text-4xl",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-muted",
				children: hint
			})
		]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-line bg-surface-2 px-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 font-mono text-lg font-semibold tracking-tight",
			children: value
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calculator, {});
}
//#endregion
export { Home as component };
