export const SUPPLY = 1_000_000_000;

export type Inputs = {
  fdv: string;
  pct: string;
  total: string;
  user: string;
};

export type Result = {
  pool: number;
  dropTokens: number;
  tokenPrice: number;
  pointPrice: number;
  share: number;
  userUsd: number;
  userTokens: number;
};

export type NumLang = "ru" | "en" | "zh";

export function parseAmount(raw: string): number {
  const trimmed = raw.trim().toLowerCase().replace(/\s/g, "").replace(",", ".");
  if (!trimmed) return Number.NaN;
  let mult = 1;
  let body = trimmed;
  const suffix = body.at(-1);
  if (suffix === "b") {
    mult = 1e9;
    body = body.slice(0, -1);
  } else if (suffix === "m") {
    mult = 1e6;
    body = body.slice(0, -1);
  } else if (suffix === "k") {
    mult = 1e3;
    body = body.slice(0, -1);
  }
  const n = Number(body);
  return Number.isFinite(n) ? n * mult : Number.NaN;
}

export function compute(fdv: number, pct: number, total: number, user: number): Result | null {
  if (![fdv, pct, total, user].every(Number.isFinite)) return null;
  if (fdv < 0 || pct < 0 || pct > 100 || total <= 0 || user < 0) return null;
  const pool = fdv * (pct / 100);
  const dropTokens = SUPPLY * (pct / 100);
  const share = user / total;
  return {
    pool,
    dropTokens,
    tokenPrice: fdv / SUPPLY,
    pointPrice: pool / total,
    share,
    userUsd: user * (pool / total),
    userTokens: dropTokens * share,
  };
}

function parts(abs: number, maxDigits: number, minDigits: number) {
  const [whole, frac = ""] = abs.toFixed(maxDigits).split(".");
  let tail = frac;
  if (tail.length > minDigits) {
    tail = tail.replace(/0+$/, "");
    if (tail.length < minDigits) tail = tail.padEnd(minDigits, "0");
  }
  return { whole, tail };
}

function group(whole: string, sep: string) {
  return whole.replace(/\B(?=(\d{3})+(?!\d))/g, sep);
}

function number(n: number, lang: NumLang, maxDigits: number, minDigits: number) {
  const sep = lang === "ru" ? "\u00a0" : ",";
  const dec = lang === "ru" ? "," : ".";
  const { whole, tail } = parts(Math.abs(n), maxDigits, minDigits);
  const body = tail ? `${group(whole, sep)}${dec}${tail}` : group(whole, sep);
  return n < 0 ? `-${body}` : body;
}

function moneyDigits(abs: number) {
  if (abs > 0 && abs < 0.0001) return { max: 8, min: 0 };
  if (abs > 0 && abs < 0.01) return { max: 6, min: 0 };
  if (abs > 0 && abs < 1) return { max: 4, min: 0 };
  return { max: 2, min: 2 };
}

export function money(n: number, lang: NumLang): string {
  const { max, min } = moneyDigits(Math.abs(n));
  const body = number(n, lang, max, min);
  return lang === "ru" ? `${body}\u00a0$` : `$${body}`;
}

export function compactUsd(n: number, lang: NumLang): string {
  const abs = Math.abs(n);
  const units: [number, string][] = [
    [1e12, "T"],
    [1e9, "B"],
    [1e6, "M"],
    [1e3, "K"],
  ];
  for (const [div, suffix] of units) {
    if (abs >= div) {
      const scaled = n / div;
      const digits = Number.isInteger(scaled) || Math.abs(scaled) >= 100 ? 0 : 2;
      const body = number(scaled, lang, digits, 0);
      return lang === "ru" ? `${body}\u00a0${suffix}\u00a0$` : `$${body}${suffix}`;
    }
  }
  return money(n, lang);
}

export function compactNum(n: number, lang: NumLang): string {
  const abs = Math.abs(n);
  const units: [number, string][] = [
    [1e12, "T"],
    [1e9, "B"],
    [1e6, "M"],
    [1e3, "K"],
  ];
  for (const [div, suffix] of units) {
    if (abs >= div) {
      const scaled = n / div;
      const digits = Number.isInteger(scaled) || Math.abs(scaled) >= 100 ? 0 : 2;
      return `${number(scaled, lang, digits, 0)}\u00a0${suffix}`;
    }
  }
  return number(n, lang, 0, 0);
}

export function tokens(n: number, lang: NumLang): string {
  const digits = Math.abs(n) >= 100 ? 0 : 2;
  return number(n, lang, digits, 0);
}

export function percent(share: number, lang: NumLang): string {
  const pct = share * 100;
  const abs = Math.abs(pct);
  const digits = abs > 0 && abs < 0.01 ? 6 : abs < 1 ? 4 : 2;
  return `${number(pct, lang, digits, 0)}%`;
}
