export type Lang = "en" | "ru" | "zh";

export const LANGS: Lang[] = ["en", "ru", "zh"];

export const LANG_LABEL: Record<Lang, string> = {
  en: "EN",
  ru: "RU",
  zh: "中文",
};

export const copy = {
  ru: {
    kicker: "Predict.fun",
    title: "Калькулятор аирдропа",
    sub: "Цена одного поинта и размер дропа в долларах. Саплай зафиксирован: 1 млрд токенов.",
    lang: "Язык",
    themeToLight: "Светлая тема",
    themeToDark: "Тёмная тема",
    inputs: "Входные данные",
    results: "Результат",
    fdv: "FDV, $",
    pct: "Доля на дроп, %",
    total: "Всего поинтов",
    yours: "Ваши поинты",
    hint: "Можно писать 150m, 1.5b, 25k",
    point: "Цена 1 поинта",
    drop: "Ваш аирдроп",
    tokens: "Ваши токены",
    tokenPrice: "Цена токена",
    pool: "Пул дропа",
    share: "Ваша доля",
    pointOf: (pool: string, points: string) => `${pool} / ${points} поинтов`,
    dropOf: (points: string, price: string) => `${points} × ${price}`,
    how: "Как считается",
    lead: "Долларовая ценность дропа — это FDV, умноженный на долю аллокации. Цена токена уже сидит внутри FDV.",
    rows: [
      ["Пул, $", "FDV × (% / 100)"],
      ["Токенов в дропе", "1 000 000 000 × (% / 100)"],
      ["Цена токена", "FDV / 1 000 000 000"],
      ["Цена 1 поинта", "пул $ / все поинты"],
      ["Аирдроп, $", "ваши поинты × цена поинта"],
      ["Ваши токены", "токены в дропе × (ваши / все)"],
    ],
    assume:
      "Допущение: весь процент делится пропорционально поинтам, без капов, мультипликаторов и отдельных бакетов.",
    disclaimer:
      "Predict.fun не публиковал токеномику и дату TGE. FDV, процент и итоговое число поинтов — сценарии, не факт. Не финансовый совет.",
    warnOver: "Ваши поинты больше общего числа — доля выше 100%.",
    warnRange: "FDV и поинты должны быть ≥ 0, доля от 0 до 100, всего поинтов больше 0.",
    warnBad: "Введите числа. Можно писать 150m, 1.5b или 25k.",
  },
  en: {
    kicker: "Predict.fun",
    title: "Airdrop calculator",
    sub: "Price of one point and your drop in dollars. Supply is fixed at 1 billion tokens.",
    lang: "Language",
    themeToLight: "Light theme",
    themeToDark: "Dark theme",
    inputs: "Inputs",
    results: "Result",
    fdv: "FDV, $",
    pct: "Airdrop allocation, %",
    total: "Total points",
    yours: "Your points",
    hint: "You can type 150m, 1.5b, 25k",
    point: "Price of 1 point",
    drop: "Your airdrop",
    tokens: "Your tokens",
    tokenPrice: "Token price",
    pool: "Airdrop pool",
    share: "Your share",
    pointOf: (pool: string, points: string) => `${pool} / ${points} points`,
    dropOf: (points: string, price: string) => `${points} × ${price}`,
    how: "How it’s calculated",
    lead: "The dollar value of the drop is FDV times the allocation. Token price is already inside the FDV.",
    rows: [
      ["Pool, $", "FDV × (% / 100)"],
      ["Drop tokens", "1,000,000,000 × (% / 100)"],
      ["Token price", "FDV / 1,000,000,000"],
      ["Price of 1 point", "pool $ / total points"],
      ["Airdrop, $", "your points × point price"],
      ["Your tokens", "drop tokens × (yours / total)"],
    ],
    assume:
      "Assumption: the whole allocation is split pro-rata by points, with no caps, multipliers, or separate buckets.",
    disclaimer:
      "Predict.fun has not published tokenomics or a TGE date. FDV, allocation, and the final point total are scenarios, not facts. Not financial advice.",
    warnOver: "Your points exceed the total — share is above 100%.",
    warnRange: "FDV and points must be ≥ 0, allocation 0–100, and total points greater than 0.",
    warnBad: "Enter numbers. You can type 150m, 1.5b, or 25k.",
  },
  zh: {
    kicker: "Predict.fun",
    title: "空投计算器",
    sub: "单个积分的价格，以及你的空投美元价值。总供应固定为 10 亿枚代币。",
    lang: "语言",
    themeToLight: "浅色主题",
    themeToDark: "深色主题",
    inputs: "输入",
    results: "结果",
    fdv: "FDV, $",
    pct: "空投比例, %",
    total: "总积分",
    yours: "你的积分",
    hint: "可以输入 150m、1.5b、25k",
    point: "1 积分价格",
    drop: "你的空投",
    tokens: "你的代币",
    tokenPrice: "代币价格",
    pool: "空投池",
    share: "你的份额",
    pointOf: (pool: string, points: string) => `${pool} / ${points} 积分`,
    dropOf: (points: string, price: string) => `${points} × ${price}`,
    how: "计算方式",
    lead: "空投的美元价值等于 FDV 乘以分配比例。代币价格已经包含在 FDV 里。",
    rows: [
      ["空投池, $", "FDV × (% / 100)"],
      ["空投代币数", "1,000,000,000 × (% / 100)"],
      ["代币价格", "FDV / 1,000,000,000"],
      ["1 积分价格", "空投池 $ / 总积分"],
      ["空投, $", "你的积分 × 积分价格"],
      ["你的代币", "空投代币数 × (你的 / 总积分)"],
    ],
    assume: "假设：全部比例按积分比例分配，没有上限、倍数或单独的份额。",
    disclaimer:
      "Predict.fun 尚未公布代币经济模型和 TGE 日期。FDV、分配比例和最终积分总量都是情景假设，不是事实。不构成财务建议。",
    warnOver: "你的积分超过总量，份额会高于 100%。",
    warnRange: "FDV 和积分必须 ≥ 0，分配比例在 0 到 100 之间，总积分必须大于 0。",
    warnBad: "请输入数字。可以写 150m、1.5b 或 25k。",
  },
} as const;

export const FDV_PRESETS = [
  { label: "$50M", value: "50000000" },
  { label: "$100M", value: "100000000" },
  { label: "$150M", value: "150000000" },
  { label: "$300M", value: "300000000" },
  { label: "$500M", value: "500000000" },
  { label: "$1B", value: "1000000000" },
];

export const PCT_PRESETS = ["5", "8", "10", "15", "20"];

export const TOTAL_PRESETS = [
  { label: "100M", value: "100000000" },
  { label: "200M", value: "200000000" },
  { label: "500M", value: "500000000" },
  { label: "1B", value: "1000000000" },
];

export const USER_PRESETS = [
  { label: "1K", value: "1000" },
  { label: "5K", value: "5000" },
  { label: "25K", value: "25000" },
  { label: "100K", value: "100000" },
  { label: "500K", value: "500000" },
];
