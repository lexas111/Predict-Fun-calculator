import { useEffect, useMemo, useState } from "react";
import { Moon, Sun } from "lucide-react";
import {
  compactNum,
  compactUsd,
  compute,
  money,
  parseAmount,
  percent,
  tokens,
  type Inputs,
} from "@/lib/calc";
import {
  copy,
  LANG_LABEL,
  LANGS,
  FDV_PRESETS,
  PCT_PRESETS,
  TOTAL_PRESETS,
  USER_PRESETS,
  type Lang,
} from "@/lib/copy";

const DEFAULTS: Inputs = {
  fdv: "150000000",
  pct: "10",
  total: "200000000",
  user: "25000",
};

function sameAmount(raw: string, preset: string) {
  const a = parseAmount(raw);
  const b = parseAmount(preset);
  return Number.isFinite(a) && a === b;
}

export function Calculator() {
  const [lang, setLang] = useState<Lang>("en");
  const [theme, setTheme] = useState<"dark" | "light">("dark");
  const [inputs, setInputs] = useState<Inputs>(DEFAULTS);
  const [hydrated, setHydrated] = useState(false);
  const t = copy[lang];

  useEffect(() => {
    try {
      if (localStorage.getItem("pf-lang-pin") === "1") {
        const savedLang = localStorage.getItem("pf-lang");
        if (savedLang === "en" || savedLang === "ru" || savedLang === "zh") setLang(savedLang);
      }
      const savedTheme = localStorage.getItem("pf-theme");
      if (savedTheme === "light" || savedTheme === "dark") setTheme(savedTheme);
      const raw = localStorage.getItem("pf-inputs");
      if (raw) {
        const parsed = JSON.parse(raw) as Partial<Inputs>;
        setInputs((prev) => ({
          fdv: typeof parsed.fdv === "string" ? parsed.fdv : prev.fdv,
          pct: typeof parsed.pct === "string" ? parsed.pct : prev.pct,
          total: typeof parsed.total === "string" ? parsed.total : prev.total,
          user: typeof parsed.user === "string" ? parsed.user : prev.user,
        }));
      }
    } catch {
      /* keep defaults */
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem("pf-lang", lang);
    document.documentElement.lang = lang === "zh" ? "zh-CN" : lang;
  }, [hydrated, lang]);

  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem("pf-theme", theme);
    document.documentElement.dataset.theme = theme;
  }, [hydrated, theme]);

  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem("pf-inputs", JSON.stringify(inputs));
  }, [hydrated, inputs]);

  const fdv = parseAmount(inputs.fdv);
  const pct = parseAmount(inputs.pct);
  const total = parseAmount(inputs.total);
  const user = parseAmount(inputs.user);
  const result = useMemo(() => compute(fdv, pct, total, user), [fdv, pct, total, user]);

  let warning = "";
  if (!result) {
    const anyNumber = [fdv, pct, total, user].some(Number.isFinite);
    const outOfRange =
      (Number.isFinite(fdv) && fdv < 0) ||
      (Number.isFinite(pct) && (pct < 0 || pct > 100)) ||
      (Number.isFinite(total) && total <= 0) ||
      (Number.isFinite(user) && user < 0);
    warning = anyNumber && outOfRange ? t.warnRange : t.warnBad;
  } else if (user > total) {
    warning = t.warnOver;
  }

  function setField(key: keyof Inputs, value: string) {
    setInputs((prev) => ({ ...prev, [key]: value }));
  }

  return (
    <main className="mx-auto min-h-screen max-w-5xl px-4 py-8 sm:px-6 sm:py-12">
      <header className="mb-8 flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
        <div className="flex items-start gap-3">
          <div
            aria-hidden="true"
            className="grid size-11 shrink-0 place-items-center rounded-xl bg-lime font-mono text-xl font-semibold text-lime-ink"
          >
            P
          </div>
          <div>
            <p className="text-sm font-medium tracking-wide text-accent">{t.kicker}</p>
            <h1 className="text-3xl font-semibold leading-tight tracking-tight sm:text-4xl">{t.title}</h1>
            <p className="mt-2 max-w-xl text-sm text-muted sm:text-base">{t.sub}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            aria-pressed={theme === "light"}
            aria-label={theme === "light" ? t.themeToDark : t.themeToLight}
            onClick={() => setTheme((current) => (current === "light" ? "dark" : "light"))}
            className="grid size-11 place-items-center rounded-full border border-line text-fg"
          >
            {theme === "light" ? <Moon className="size-5" /> : <Sun className="size-5" />}
          </button>
          <div role="group" aria-label={t.lang} className="inline-flex rounded-full border border-line p-1">
            {LANGS.map((code) => (
              <button
                key={code}
                type="button"
                aria-pressed={lang === code}
                onClick={() => {
                  localStorage.setItem("pf-lang-pin", "1");
                  setLang(code);
                }}
                className={
                  "min-h-11 rounded-full px-3 text-sm font-semibold transition-colors " +
                  (lang === code ? "bg-lime text-lime-ink" : "text-muted")
                }
              >
                {LANG_LABEL[code]}
              </button>
            ))}
          </div>
        </div>
      </header>

      <div className="grid gap-4 lg:grid-cols-2">
        <section className="rounded-2xl border border-line bg-surface p-5">
          <h2 className="text-sm font-medium text-muted">{t.inputs}</h2>
          <Field
            id="fdv"
            label={t.fdv}
            value={inputs.fdv}
            onChange={(v) => setField("fdv", v)}
            presets={FDV_PRESETS}
          />
          <p className="mt-2 text-xs text-muted">{t.hint}</p>
          <Field
            id="pct"
            label={t.pct}
            value={inputs.pct}
            onChange={(v) => setField("pct", v)}
            presets={PCT_PRESETS.map((value) => ({ label: `${value}%`, value }))}
          />
          <Field
            id="total"
            label={t.total}
            value={inputs.total}
            onChange={(v) => setField("total", v)}
            presets={TOTAL_PRESETS}
          />
          <Field
            id="user"
            label={t.yours}
            value={inputs.user}
            onChange={(v) => setField("user", v)}
            presets={USER_PRESETS}
          />
          <p className="mt-4 min-h-5 text-sm text-warn" role="status">
            {warning}
          </p>
        </section>

        <section className="rounded-2xl border border-line bg-surface p-5" aria-live="polite">
          <h2 className="text-sm font-medium text-muted">{t.results}</h2>
          <div className="mt-4 grid gap-3">
            <Hero
              label={t.point}
              value={result ? money(result.pointPrice, lang) : "—"}
              hint={
                result ? t.pointOf(compactUsd(result.pool, lang), compactNum(total, lang)) : t.pointOf("—", "—")
              }
            />
            <Hero
              label={t.drop}
              value={result ? money(result.userUsd, lang) : "—"}
              hint={
                result
                  ? t.dropOf(compactNum(user, lang), money(result.pointPrice, lang))
                  : t.dropOf("—", "—")
              }
            />
            <div className="grid grid-cols-2 gap-3">
              <Stat label={t.tokens} value={result ? tokens(result.userTokens, lang) : "—"} />
              <Stat label={t.tokenPrice} value={result ? money(result.tokenPrice, lang) : "—"} />
              <Stat label={t.pool} value={result ? compactUsd(result.pool, lang) : "—"} />
              <Stat label={t.share} value={result ? percent(result.share, lang) : "—"} />
            </div>
          </div>
        </section>
      </div>

      <section className="mt-4 rounded-2xl border border-line bg-surface p-5">
        <h2 className="text-lg font-semibold tracking-tight">{t.how}</h2>
        <p className="mt-2 max-w-3xl text-sm text-muted">{t.lead}</p>
        <ul className="mt-4 space-y-2">
          {t.rows.map(([label, expr]) => (
            <li key={label} className="flex flex-col gap-0.5 text-sm sm:flex-row sm:items-baseline sm:gap-3">
              <span className="text-muted sm:w-44 sm:shrink-0">{label}</span>
              <code className="font-mono text-fg">{expr}</code>
            </li>
          ))}
        </ul>
        <p className="mt-4 text-sm text-muted">{t.assume}</p>
      </section>

      <p className="mt-4 max-w-3xl text-xs leading-relaxed text-muted">{t.disclaimer}</p>
    </main>
  );
}

function Field({
  id,
  label,
  value,
  onChange,
  presets,
}: {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  presets: { label: string; value: string }[];
}) {
  return (
    <div className="mt-4">
      <label htmlFor={id} className="mb-2 block text-sm text-muted">
        {label}
      </label>
      <input
        id={id}
        value={value}
        inputMode="decimal"
        autoComplete="off"
        onChange={(e) => onChange(e.target.value)}
        className="min-h-11 w-full rounded-xl border border-line bg-surface-2 px-4 font-mono text-base text-fg"
      />
      <div className="mt-2 flex flex-wrap gap-2">
        {presets.map((preset) => {
          const active = sameAmount(value, preset.value);
          return (
            <button
              key={preset.value}
              type="button"
              aria-pressed={active}
              onClick={() => onChange(preset.value)}
              className={
                "min-h-11 rounded-full border px-3 text-sm font-medium transition-colors " +
                (active ? "border-lime bg-lime text-lime-ink" : "border-line text-muted")
              }
            >
              {preset.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}

function Hero({ label, value, hint }: { label: string; value: string; hint: string }) {
  return (
    <div className="rounded-2xl border border-line bg-surface-2 px-4 py-4">
      <p className="text-xs text-muted">{label}</p>
      <p className="mt-1 font-mono text-3xl font-semibold tracking-tight text-accent sm:text-4xl">{value}</p>
      <p className="mt-1 text-xs text-muted">{hint}</p>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-line bg-surface-2 px-3 py-3">
      <p className="text-xs text-muted">{label}</p>
      <p className="mt-1 font-mono text-lg font-semibold tracking-tight">{value}</p>
    </div>
  );
}
