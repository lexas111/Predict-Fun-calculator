import { createFileRoute } from "@tanstack/react-router";
import { Calculator } from "@/components/calculator";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Predict.fun — Airdrop calculator" },
      {
        name: "description",
        content:
          "Estimate the Predict.fun point price and airdrop value from FDV, allocation, and points. Russian and English.",
      },
    ],
  }),
  component: Home,
});

function Home() {
  return <Calculator />;
}
